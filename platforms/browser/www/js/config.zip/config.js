var krms_config ={			
	'ApiUrl':"https://paymeal.app/singlemerchant/api",			
	'DialogDefaultTitle':"PayCart",			
	'MerchantKeys':"1c630b2a586ef8ad95ecffa82571f3ff",
	'debug': false
};